//
//  SetViewController.h
//  MyMusicPlayer_date_30_1
//
//  Created by Admin on 16/2/16.
//  Copyright © 2016年 Jason_zzzz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *setButton;

@end
