//
//  FirstCell.m
//  MyMusicPlayer_date_30_1
//
//  Created by Jason_zzzz on 16/2/2.
//  Copyright © 2016年 Jason_zzzz. All rights reserved.
//

#import "FirstCell.h"

@interface FirstCell()

@end

@implementation FirstCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
