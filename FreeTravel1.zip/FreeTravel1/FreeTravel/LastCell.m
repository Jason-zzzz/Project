//
//  LastCell.m
//  FreeTravel
//
//  Created by Admin on 16/2/24.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "LastCell.h"

@implementation LastCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
