//
//  DesCollectionView.h
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/13.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DesCollectionView : UICollectionView

@property (nonatomic, strong) NSMutableArray *cityArr;
@property (nonatomic, strong) NSMutableArray *cityImageArr;
@property (nonatomic, strong) NSMutableArray *sectionCityImage;

@end
