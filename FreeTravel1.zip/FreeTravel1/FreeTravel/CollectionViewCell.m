//
//  CollectionViewCell.m
//  FreeTravel
//
//  Created by Admin on 16/3/7.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "CollectionViewCell.h"

@interface CollectionViewCell () {
    
}

@property (weak, nonatomic) IBOutlet UILabel *chineseNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *engNameLabel;
@property (weak, nonatomic) IBOutlet UIButton *cityImage;

@end

@implementation CollectionViewCell

- (void)setCityImage:(UIImage *)cityImage {
    
}

- (void)setChineseName:(NSString *)chineseName {
    self.chineseNameLabel.text = chineseName;
}

- (void)setEngName:(NSString *)engName {
    self.engNameLabel.text = engName;
}

@end
