//
//  SecondCell.h
//  FreeTravel
//
//  Created by Admin on 16/2/24.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *secondImage;
@property (weak, nonatomic) IBOutlet UILabel *secondLabel;

@end
