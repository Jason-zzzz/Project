//
//  PP2CollectionViewCell.m
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/9.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "PP2CollectionViewCell.h"

@implementation PP2CollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
