//
//  PPfirstCell.m
//  FreeTravel
//
//  Created by Admin on 16/3/4.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "PPfirstCell.h"

@interface PPfirstCell () {
}

@end

@implementation PPfirstCell

@end
