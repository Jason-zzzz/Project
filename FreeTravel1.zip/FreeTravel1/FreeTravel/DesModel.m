//
//  DesModel.m
//  FreeTravel
//
//  Created by Admin on 16/3/7.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "DesModel.h"

@implementation DesModel

@end
