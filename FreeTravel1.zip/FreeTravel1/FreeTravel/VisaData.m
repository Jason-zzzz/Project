//
//  VisaData.m
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/16.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "VisaData.h"

@implementation VisaData


@end
