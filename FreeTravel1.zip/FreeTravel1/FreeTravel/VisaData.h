//
//  VisaData.h
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/16.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VisaData : NSObject

@property (nonatomic, copy) NSString * imgUrl;
@property (nonatomic, copy) NSString * url;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * pic;

@end
