//
//  PPsecondCell.m
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/9.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "PPsecondCell.h"

@implementation PPsecondCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
