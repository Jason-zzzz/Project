//
//  SearchViewController.h
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/7.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UISearchController

@end
