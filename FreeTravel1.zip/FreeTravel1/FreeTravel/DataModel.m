//
//  DataModel.m
//  FreeTravel
//
//  Created by Jason_zzzz on 16/3/4.
//  Copyright © 2016年 Miko. All rights reserved.
//

#import "DataModel.h"

@interface DataModel () <NSURLSessionDelegate> {
}

@end

@implementation DataModel

@synthesize destinationState = destinationState_;

+ (id)allocWithZone:(struct _NSZone *)zone{
    return [self defaultObject];
}

+ (DataModel *)defaultObject{
    
    static DataModel *singleInstance = nil;
    if (!singleInstance) {
        singleInstance = [[super allocWithZone:NULL] init];
    }
    return singleInstance;
}

- (void)getData:(NSString *)urlString{
    
    // 构建Request
    NSString *encodeUrl = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    //    NSLog(@"%@",encodeUrl);
    NSURL *url = [NSURL URLWithString:encodeUrl];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // 构建session的congigurations
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    // 构建NSUrlSession
    NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:self delegateQueue:nil];
    
    if (!destinationState_) {
        
        // 得到Task对象
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                            NSLog(@"%@",dic);
            NSArray *dataArr = [dic objectForKey:@"data"];
            
            destinationState_ = [NSMutableArray array];
            destinationState_ = (NSMutableArray *)dataArr;
            //        for (NSDictionary *d in dataArr) {
            //            [destinationState_ addObject:[d objectForKey:@"name"]];
            //        }
            //
            //        for (NSDictionary *s in dataArr) {
            //
            //        }
//                    NSLog(@"%@",destinationState_);
            [_modelDelegate finishGetData];
        }];
        [dataTask resume];
    } else {
        [_modelDelegate finishGetData];        
    }
}

- (void)getCityImagesWith: (NSIndexPath *)cityIndex andUrl:(NSString *)cityImageUrl {
    
    // 异步下载
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // 下载
        NSURL *url = [NSURL URLWithString:cityImageUrl];
        NSData *data = [NSData dataWithContentsOfURL:url];
        UIImage *image = [UIImage imageWithData:data];
        
        [_modelDelegate finishGetCityImage:image andIndex:cityIndex];
    });
}
@end
